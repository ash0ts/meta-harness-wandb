"""Reproduce the article's comparisons from the accompanying 252-row CSV.

Run: python reproduce_comparisons.py all-252-results.csv
Uses the unmodified, predeclared study_analysis.py shipped beside this script.
No model calls, external packages or network access are needed.
"""
import csv
import json
import sys
from statistics import mean
from study_analysis import paired_analysis

with open(sys.argv[1]) as stream:
    rows=list(csv.DictReader(stream))
for r in rows:
    r['trial']=int(r['trial'])
    r['score']=float(r['score']) if r['score'] else None
assert len(rows)==252
output={}
code=[r for r in rows if r['study']=='code']
output['coding_means_percent']={c:mean(r['score'] for r in code if r['condition']==c)*100 for c in ['baseline','harness2','diagnostics']}
for label,left,right in [('diagnostics_vs_raw','diagnostics','harness2'),('raw_vs_original','harness2','baseline'),('diagnostics_vs_original','diagnostics','baseline')]:
    mapping={left:'diagnostics',right:'harness2'}
    mapping[next(c for c in ['baseline','harness2','diagnostics'] if c not in mapping)]='baseline'
    analysis=paired_analysis([{**r,'condition':mapping[r['condition']]} for r in code],trials=3)
    output[label]={k:analysis[k] for k in ['diagnostics_minus_raw_pp','interval_95_pp','wins','ties','losses','supported_gain','supported_loss','practically_equivalent']}
output['jobbench']=paired_analysis([r for r in rows if r['study']=='jobbench'],trials=2)
print(json.dumps(output,indent=2))
