# Reproduce the final Harness² article analysis

Run `python reproduce_comparisons.py all-252-results.csv` with Python 3.10 or later. The calculation needs no network, model calls or external packages. `study_analysis.py` is an unchanged copy of the study's predeclared estimator.

The 252-row CSV uses native scores from 0 to 1. Task-summary CSVs use percentages. Missing grades are empty, never zero. Coding has 216 scores over 24 tasks, eight adaptation groups and three trials. JobBench has 33 of 36 scores over six tasks and two trials, and gets no complete-design aggregate.

The estimator averages trials within each task, weights tasks equally and resamples groups, paired trials and tasks with shared harness relationships preserved. It uses 10,000 draws, seed 20261022, 95% percentile intervals and a ±5-point equivalence band. The script also reproduces both baseline comparisons through the same paired estimator.

Original and repeated JobBench grades remain separate. Earlier pilots are not pooled. These computations do not rerun an agent or a judge. The full W&B evidence release contains the traces, outputs, harnesses and native grading material for audit.

`analysis.json` records the full evidence reconciliation, cost accounting and missingness sensitivity. `standalone-reproduction.json` is the expected script output. Source attribution and licensing follow the experiment fork's LICENSE.
