import json
import sqlite3
from types import SimpleNamespace

import pytest

from harness2.showcase.runtime import CampaignStop, fingerprint
from harness2.showcase.supervisor_v4 import durable_ready, ledger_ready, recovery_reason


@pytest.mark.parametrize(
    "reason",
    [
        "Stored tool result differs",
        "Returned model differs from frozen requested model",
        "Runtime differs from qualified source or images",
        "Missing provider usage",
        "Budget ceiling reached",
        "Child completion is unproven",
    ],
)
def test_unknown_or_semantic_failures_never_automatically_resume(reason):
    assert recovery_reason({"phase": "stopped"}, {"reason": reason}) is None
    assert (
        recovery_reason(
            {"phase": "stopped"},
            {
                "reason": "Trace persistence failed for " + "a" * 32 + ": " + reason,
            },
        )
        is None
    )


def test_only_known_transient_export_or_missing_controller_is_eligible():
    assert recovery_reason({"phase": "adapt"}, None) == "resume_missing_controller"
    assert recovery_reason({"phase": "awaiting_evidence_review"}, None) is None
    assert recovery_reason({"phase": "paused"}, None) is None
    assert (
        recovery_reason(
            {}, {"reason": "Trace persistence failed for " + "a" * 32 + ": connection timed out"}
        )
        == "retry_trace_export"
    )


def test_pending_unknown_and_exhausted_budget_block_recovery(tmp_path):
    path = tmp_path / "gateway/budget.sqlite"
    path.parent.mkdir()
    with sqlite3.connect(path) as db:
        db.execute("CREATE TABLE calls(status TEXT,spent INTEGER,reserved INTEGER)")
        db.execute("INSERT INTO calls VALUES ('complete',1000000,2000000)")
    ledger_ready(tmp_path, 500)
    for status in ("pending", "unknown"):
        with sqlite3.connect(path) as db:
            db.execute("INSERT INTO calls VALUES (?,NULL,1000000)", (status,))
        with pytest.raises(CampaignStop):
            ledger_ready(tmp_path, 500)
        with sqlite3.connect(path) as db:
            db.execute("DELETE FROM calls WHERE status=?", (status,))
    with sqlite3.connect(path) as db:
        db.execute("INSERT INTO calls VALUES ('bounded_unknown',NULL,499000000)")
    with pytest.raises(CampaignStop, match="budget"):
        ledger_ready(tmp_path, 500)


def test_no_child_completion_means_no_restart(tmp_path):
    op = tmp_path / "operations/op.json"
    op.parent.mkdir()
    op.write_text('{"status":"started"}')
    identity = tmp_path / "executions/session/identity.json"
    identity.parent.mkdir(parents=True)
    identity.write_text('{"operation_key":"op"}')
    rt = SimpleNamespace(state=tmp_path, calls=lambda _: [], wait_calls=lambda _: [])
    with pytest.raises(CampaignStop, match="completion"):
        durable_ready(rt)
    process = identity.parent / "opencode-db/process.json"
    process.parent.mkdir()
    process.write_text('{"ended":3,"child_exit_code":7}')
    durable_ready(rt)  # Failed agent executions remain failed, not re-executed.


def test_unregistered_queued_input_is_safe_but_changed_input_is_not(tmp_path):
    durable = tmp_path / "durable-work/op"
    durable.mkdir(parents=True)
    (durable / "input").write_text("original")
    op = tmp_path / "operations/op.json"
    op.parent.mkdir()
    op.write_text(json.dumps({"status": "queued", "input_fingerprint": fingerprint(durable)}))
    rt = SimpleNamespace(state=tmp_path)
    durable_ready(rt)
    (durable / "input").write_text("changed")
    with pytest.raises(CampaignStop):
        durable_ready(rt)
