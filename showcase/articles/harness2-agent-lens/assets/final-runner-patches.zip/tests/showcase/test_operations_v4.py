import json
import threading
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import pytest

from harness2.showcase.operations_v4 import POLICY, proposal_slots, worker_limit, worker_slot
from harness2.showcase.runtime import CampaignStop, Runtime
from harness2.showcase.runtime_v4 import StudyRuntime


def runtime(tmp_path):
    manifest = json.loads(Path("showcase/study-v4.json").read_text())
    return StudyRuntime(manifest, tmp_path / "state")


def amend(rt):
    path = rt.state / "runtime-repairs/parallel-throughput.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps({"execution_policy": POLICY}))


def test_legacy_limit_and_bounded_operational_override(tmp_path):
    rt = runtime(tmp_path)
    assert worker_limit(rt) == 2
    amend(rt)
    assert worker_limit(rt) == POLICY["max_worker_containers"]
    control = rt.state / "worker-control.json"
    control.write_text('{"limit": 4}')
    assert worker_limit(rt) == 4
    for value in (0, POLICY["max_worker_containers"] + 1, True, "4"):
        control.write_text(json.dumps({"limit": value}))
        with pytest.raises(CampaignStop):
            worker_limit(rt)


def test_larger_evaluation_capacity_requires_all_adaptations_frozen(tmp_path):
    from harness2.showcase.operations_v4 import EVALUATION_POLICY, execution_policy

    rt = runtime(tmp_path)
    amend(rt)
    receipt = rt.state / "runtime-repairs/parallel-throughput.json"
    receipt.write_text(
        json.dumps({"execution_policy": POLICY, "evaluation_policy": EVALUATION_POLICY})
    )
    control = rt.state / "worker-control.json"
    control.write_text('{"limit": 16}')
    assert execution_policy(rt)["max_worker_containers"] == 8
    with pytest.raises(CampaignStop):
        worker_limit(rt)
    (rt.state / "adapt-complete.json").write_text('{"complete":true}')
    assert worker_limit(rt) == 16
    assert execution_policy(rt)["grading_workers"] == 4
    control.write_text('{"limit": 33}')
    with pytest.raises(CampaignStop):
        worker_limit(rt)
    receipt.write_text(
        json.dumps(
            {
                "execution_policy": POLICY,
                "evaluation_policy": {**EVALUATION_POLICY, "max_worker_containers": 64},
            }
        )
    )
    with pytest.raises(CampaignStop, match="evaluation scheduling"):
        execution_policy(rt)


@pytest.mark.parametrize("capacity", [8, 16, 24, 32])
def test_slots_shared_between_studies_and_release_on_failure(tmp_path, monkeypatch, capacity):
    monkeypatch.setitem(POLICY, "max_worker_containers", capacity)
    rt = runtime(tmp_path)
    amend(rt)
    other = StudyRuntime(rt.manifest, rt.state, "jobbench")
    entered, release = threading.Barrier(capacity + 1), threading.Event()

    def occupy(index):
        with worker_slot(rt if index % 2 else other) as limit:
            assert limit == capacity
            entered.wait(timeout=3)
            assert release.wait(timeout=3)

    with ThreadPoolExecutor(max_workers=capacity) as pool:
        jobs = [pool.submit(occupy, i) for i in range(capacity)]
        entered.wait(timeout=3)
        release.set()
        for job in jobs:
            job.result()
    with pytest.raises(ValueError), worker_slot(rt):
        raise ValueError("release slot")
    with worker_slot(other) as limit:
        assert limit == capacity


def test_upstream_proposer_allows_eight_independent_calls_then_restores_cap(tmp_path, monkeypatch):
    from harness2.core import proposer
    from harness2.core.spec import ChannelSpec

    rt = runtime(tmp_path)
    amend(rt)
    old_semaphore = proposer._SEM
    entered = threading.Barrier(8)

    def local_call(self, cwd, mission, system, wall):
        entered.wait(timeout=5)
        return "completed local fixture", 0, ""

    monkeypatch.setattr(proposer.Proposer, "_opencode", local_call)

    def run(index):
        instance = proposer.Proposer(ChannelSpec(kind="opencode", model="local-fixture"))
        return instance.call("fixture mission", None, f"stage-{index}", max_attempts=1)

    with proposal_slots(rt), ThreadPoolExecutor(max_workers=8) as pool:
        replies = list(pool.map(run, range(8)))
    assert all(reply.ok for reply in replies)
    assert proposer._SEM is old_semaphore


def test_queued_handoff_launches_once_and_reuses_original_input(tmp_path, monkeypatch):
    rt = runtime(tmp_path)
    work = tmp_path / "work"
    work.mkdir()
    (work / "input").write_text("original")

    @contextmanager
    def interrupted(_):
        raise CampaignStop("dispatcher handoff")
        yield

    monkeypatch.setattr("harness2.showcase.runtime_v4.worker_slot", interrupted)
    kwargs = dict(phase="adapt", role="solver", task="task", arm="harness2")
    with pytest.raises(CampaignStop):
        rt.run_agent(work, "mission", **kwargs)
    launches = []

    def launch(self, directory, prompt, **identity):
        assert (directory / "input").read_text() == "original"
        launches.append(1)
        execution = self.state / "executions/session"
        execution.mkdir(parents=True)
        identity["session"] = "session"
        (execution / "identity.json").write_text(json.dumps(identity))
        result = {"session": "session", "collection_status": "complete", "child_exit_code": 0}
        (execution / "execution.json").write_text(json.dumps(result))
        return result, execution

    monkeypatch.setattr("harness2.showcase.runtime_v4.worker_slot", worker_slot)
    monkeypatch.setattr(Runtime, "run_agent", launch)
    monkeypatch.setattr(rt, "wait_calls", lambda _: [])
    (work / "input").write_text("caller reconstruction")
    rt.run_agent(work, "mission", **kwargs)
    rt.run_agent(work, "mission", **kwargs)
    assert len(launches) == 1


def test_registered_or_changed_queued_inputs_are_never_relaunched(tmp_path):
    from harness2.showcase.operations_v4 import verify_unlaunched_queue
    from harness2.showcase.runtime import fingerprint

    rt = runtime(tmp_path)
    durable = tmp_path / "durable"
    durable.mkdir()
    (durable / "file").write_text("original")
    record = {"status": "queued", "input_fingerprint": fingerprint(durable)}
    verify_unlaunched_queue(rt, "op", record, durable)
    registered = rt.state / "gateway/sessions/session/identity.json"
    registered.parent.mkdir(parents=True)
    registered.write_text('{"operation_key":"op"}')
    with pytest.raises(CampaignStop, match="registered"):
        verify_unlaunched_queue(rt, "op", record, durable)
    registered.unlink()
    (durable / "file").write_text("changed")
    with pytest.raises(CampaignStop, match="changed"):
        verify_unlaunched_queue(rt, "op", record, durable)
    with pytest.raises(CampaignStop, match="uncertain"):
        verify_unlaunched_queue(rt, "op", {**record, "status": "started"}, durable)


def test_independent_conditions_wait_for_their_shared_baseline(tmp_path, monkeypatch):
    from harness2.showcase.v4 import adapt

    rt = runtime(tmp_path)
    amend(rt)
    rt.manifest["studies"]["code"]["adaptation_trials"] = 1
    groups = [{"group": "one"}, {"group": "two"}]
    baselines, operations = set(), []
    both_conditions = threading.Barrier(4)

    def one(runtime, group, arm, trial):
        if arm == "baseline":
            baselines.add(group["group"])
            return
        assert group["group"] in baselines
        operations.append((group["group"], arm, trial))
        both_conditions.wait(timeout=3)

    monkeypatch.setattr("harness2.showcase.v4.forecast", lambda _: None)
    monkeypatch.setattr("harness2.showcase.v4.verify_qualified_engine", lambda _: None)
    monkeypatch.setattr("harness2.showcase.v4.groups", lambda _: groups)
    monkeypatch.setattr("harness2.showcase.v4.adapt_one", one)
    adapt(rt)
    assert len(operations) == len(set(operations)) == 4


def test_grading_barrier_and_missingness_survive_parallelism(tmp_path, monkeypatch):
    from harness2.showcase.v4 import grade

    rt = runtime(tmp_path)
    amend(rt)
    path = rt.state / "evaluations"
    path.mkdir()
    for task in ("available", "unavailable"):
        (path / (task + ".json")).write_text(
            json.dumps(
                {
                    "study": "code",
                    "status": "awaiting_judgment",
                    "condition": "harness2",
                    "trial": 1,
                    "task": task,
                    "output": task,
                }
            )
        )
    scored = []

    def score(_, task):
        scored.append(task)
        return {"score": 0.5} if task == "available" else None

    monkeypatch.setattr("harness2.showcase.v4.adapter", lambda *args: SimpleNamespace(score=score))
    grade(rt)
    assert not scored
    (rt.state / "execute-complete.json").write_text("{}")
    grade(rt)
    grade(rt)
    assert sorted(scored) == ["available", "unavailable"]
    missing = json.loads((path / "unavailable.json").read_text())
    assert missing["score"] is None and missing["status"] == "unavailable_judgment"


def test_four_independent_native_graders_keep_separate_results(tmp_path, monkeypatch):
    from harness2.showcase.v4 import grade

    monkeypatch.setitem(POLICY, "grading_workers", 4)
    rt = runtime(tmp_path)
    amend(rt)
    (rt.state / "execute-complete.json").write_text("{}")
    rows = rt.state / "evaluations"
    rows.mkdir()
    for index in range(4):
        (rows / f"{index}.json").write_text(
            json.dumps(
                {
                    "study": "code",
                    "status": "awaiting_judgment",
                    "condition": "harness2",
                    "trial": index + 1,
                    "task": str(index),
                    "output": str(index),
                }
            )
        )
    entered = threading.Barrier(4)

    def score(output, task):
        assert str(output) == task
        entered.wait(timeout=5)
        return {"score": int(task) / 4}

    monkeypatch.setattr("harness2.showcase.v4.adapter", lambda *args: SimpleNamespace(score=score))
    grade(rt)
    assert [json.loads((rows / f"{i}.json").read_text())["score"] for i in range(4)] == [
        0,
        0.25,
        0.5,
        0.75,
    ]
