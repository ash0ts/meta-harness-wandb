"""Recorded host scheduling changes; agent settings and operation keys stay fixed."""

import json
import threading
from contextlib import contextmanager

from .runtime import CampaignStop

_POOLS = {}
_LOCK = threading.Lock()
POLICY = {
    "max_worker_containers": 8,
    "max_concurrent_proposers": 8,
    "adaptation_scheduler": "independent_conditions",
    "grading_workers": 2,
}
EVALUATION_POLICY = {**POLICY, "max_worker_containers": 32, "grading_workers": 4}


def execution_policy(runtime):
    receipt = runtime.state / "runtime-repairs/parallel-throughput.json"
    if not receipt.exists():
        return {
            "max_worker_containers": 2,
            "max_concurrent_proposers": 2,
            "adaptation_scheduler": "sequential_conditions",
            "grading_workers": 1,
        }
    amendment = json.loads(receipt.read_text())
    value = amendment.get("execution_policy")
    if value != POLICY:
        raise CampaignStop("Unrecognized execution scheduling amendment")
    evaluation = amendment.get("evaluation_policy")
    if evaluation is not None and evaluation != EVALUATION_POLICY:
        raise CampaignStop("Unrecognized evaluation scheduling amendment")
    if evaluation and (runtime.state / "adapt-complete.json").exists():
        return dict(evaluation)
    return dict(value)


@contextmanager
def proposal_slots(runtime):
    """Scope upstream's host-only proposer cap to this recorded v4 campaign."""
    from harness2.core import proposer

    policy = execution_policy(runtime)
    previous = proposer._SEM
    proposer._SEM = threading.BoundedSemaphore(policy["max_concurrent_proposers"])
    try:
        yield
    finally:
        proposer._SEM = previous


def worker_limit(runtime):
    maximum = execution_policy(runtime)["max_worker_containers"]
    control = runtime.state / "worker-control.json"
    value = json.loads(control.read_text())["limit"] if control.exists() else maximum
    if type(value) is not int or not 1 <= value <= maximum:
        raise CampaignStop("Worker limit exceeds the recorded scheduling amendment")
    return value


@contextmanager
def worker_slot(runtime):
    """Share a live limit across studies; lowering it drains existing work."""
    key = str(runtime.state.resolve())
    with _LOCK:
        pool = _POOLS.setdefault(key, {"condition": threading.Condition(), "active": 0})
    condition = pool["condition"]
    with condition:
        while pool["active"] >= worker_limit(runtime):
            condition.wait(timeout=0.5)
        limit = worker_limit(runtime)
        pool["active"] += 1
    try:
        yield limit
    finally:
        with condition:
            pool["active"] -= 1
            condition.notify_all()


def verify_unlaunched_queue(runtime, key, record, durable):
    """A durable queued input can resume only if no session was ever registered."""
    from .runtime import fingerprint

    if record.get("status") != "queued" or not durable.is_dir():
        raise CampaignStop(f"Execution state is uncertain for {key}; preserve and reconcile")
    for path in (runtime.state / "gateway/sessions").glob("*/identity.json"):
        if json.loads(path.read_text()).get("operation_key") == key:
            raise CampaignStop(f"Queued operation {key} already registered a session")
    if fingerprint(durable) != record.get("input_fingerprint"):
        raise CampaignStop(f"Queued input changed for {key}")
