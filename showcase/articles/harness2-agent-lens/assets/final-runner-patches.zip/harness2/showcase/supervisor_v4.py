"""Bounded recovery of stopped infrastructure; never change experimental evidence."""

import argparse
import fcntl
import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

from .operations_v4 import verify_unlaunched_queue
from .runtime import ROOT, CampaignStop
from .runtime_v4 import StudyRuntime
from .v4 import verify_qualified_engine
from .workbuddy_preflight import save


def recovery_reason(sequence, stopped):
    if stopped:
        reason = stopped.get("reason", "")
        transient = (
            "timed out",
            "timeout",
            "connecterror",
            "connection",
            "remoteprotocolerror",
            "trace flush did not complete",
            "502",
            "503",
            "504",
        )
        if reason.startswith("Trace persistence failed") and any(
            term in reason.lower() for term in transient
        ):
            return "retry_trace_export"
        return None
    if sequence.get("phase") in ("adapt", "evaluate", "report"):
        return "resume_missing_controller"
    return None


def ledger_ready(state, ceiling):
    if (state / "gateway/halted.json").exists():
        raise CampaignStop("Gateway has an unresolved halt")
    with sqlite3.connect((state / "gateway/budget.sqlite").as_uri() + "?mode=ro", uri=True) as db:
        rows = db.execute("SELECT status,spent,reserved FROM calls").fetchall()
    if any(status in ("pending", "unknown") for status, _, _ in rows):
        raise CampaignStop("Pending or unbounded calls prevent automatic recovery")
    total = (
        sum(
            reserved if status == "bounded_unknown" else spent or 0
            for status, spent, reserved in rows
        )
        / 1_000_000
    )
    if total >= ceiling:
        raise CampaignStop("Campaign budget has no remaining capacity")


def durable_ready(runtime):
    """Reject every possibly still-running operation, even without a Docker name."""
    identities = {}
    for p in (runtime.state / "executions").glob("*/identity.json"):
        identity = json.loads(p.read_text())
        identities.setdefault(identity.get("operation_key"), []).append(p.parent)
    for path in (runtime.state / "operations").glob("*.json"):
        record = json.loads(path.read_text())
        if record.get("status") == "complete":
            continue
        matches = identities.get(path.stem, [])
        if not matches:
            verify_unlaunched_queue(
                runtime, path.stem, record, runtime.state / "durable-work" / path.stem
            )
            continue
        if len(matches) != 1:
            raise CampaignStop("Operation has ambiguous execution identities")
        directory = matches[0]
        process = directory / "opencode-db/process.json"
        if not process.is_file():
            raise CampaignStop("Child completion is not proven")
        child = json.loads(process.read_text())
        if child.get("ended") is None or child.get("child_exit_code") is None:
            raise CampaignStop("Child completion receipt is incomplete")
        calls = runtime.calls(directory.name)
        if calls:
            runtime.wait_calls(directory.name)


def configured_environment(manifest):
    """Reuse the gateway's configured credential in memory, never in a plist/log."""
    env = dict(os.environ, PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin")
    if not env.get("WANDB_API_KEY"):
        result = subprocess.run(
            [
                "docker",
                "inspect",
                "--format",
                "{{json .Config.Env}}",
                manifest["network"] + "-gateway",
            ],
            capture_output=True,
            text=True,
            check=True,
            timeout=10,
        )
        for item in json.loads(result.stdout):
            if item.startswith("WANDB_API_KEY="):
                env["WANDB_API_KEY"] = item.split("=", 1)[1]
                break
    if not env.get("WANDB_API_KEY"):
        raise CampaignStop("Configured experiment credential unavailable")
    return env


def supervise(state, sequence_script, release_runner=lambda: None):
    if (state / "maintenance.json").exists():
        return {"action": "maintenance"}
    sequence = json.loads((state / "sequence-status.json").read_text())
    if sequence.get("phase") == "awaiting_evidence_review":
        return {"action": "finished"}
    pid = sequence.get("pid")
    if pid:
        process = subprocess.run(
            ["ps", "-p", str(pid), "-o", "command="], capture_output=True, text=True
        )
        if process.returncode == 0 and str(sequence_script) in process.stdout:
            return {"action": "running"}
    stop_path = state / "stopped.json"
    stopped = json.loads(stop_path.read_text()) if stop_path.exists() else None
    reason = recovery_reason(sequence, stopped)
    if not reason:
        return {"action": "needs_review", "reason": "Stop is not an approved transient failure"}
    history_path = state / "supervisor/recoveries.json"
    history = json.loads(history_path.read_text()) if history_path.exists() else []
    recent = [r for r in history if time.time() - r["at"] < 3600]
    if len(recent) >= 3 or (recent and time.time() - recent[-1]["at"] < 300):
        return {"action": "cooldown", "reason": "At most three recovery attempts per hour"}
    manifest = json.loads((state / "manifest.json").read_text())
    runtime = StudyRuntime(manifest, state)
    verify_qualified_engine(runtime)
    ledger_ready(state, float(manifest["budget_usd"]))
    names = subprocess.run(
        ["docker", "ps", "--filter", "name=h2-", "--format", "{{.Names}}"],
        capture_output=True,
        text=True,
        check=True,
        timeout=10,
    ).stdout.splitlines()
    if any(
        (state / "executions" / name.removeprefix("h2-")).exists()
        or name.startswith("h2-v4-grader-")
        for name in names
    ):
        return {"action": "draining", "reason": "Existing execution or grader is still running"}
    durable_ready(runtime)
    env = configured_environment(manifest)
    os.environ["WANDB_API_KEY"] = env["WANDB_API_KEY"]
    attempt = {"at": time.time(), "reason": reason, "outcome": "started"}
    history.append(attempt)
    save(history_path, history)
    if reason == "retry_trace_export":
        from .collect_v4 import recover
        from .telemetry import export_session

        match = re.search(r"Trace persistence failed for ([a-f0-9]{32})", stopped["reason"])
        if not match:
            raise CampaignStop("Stopped trace has no unambiguous saved session")
        directory = state / "executions" / match[1]
        result = json.loads((directory / "execution.json").read_text())
        if result.get("collection_status") != "complete":
            result = recover(directory, runtime)
        runtime.wait_calls(match[1])
        export_session(runtime, match[1], result, directory)
    if stop_path.exists():
        archive = state / "supervisor" / f"stopped-{time.time_ns()}.json"
        shutil.copyfile(stop_path, archive)
        if (
            hashlib.sha256(stop_path.read_bytes()).digest()
            != hashlib.sha256(archive.read_bytes()).digest()
        ):
            raise CampaignStop("Stop archive differs")
        stop_path.unlink()
    release_runner()
    with (state / "supervisor/controller.log").open("a") as log:
        process = subprocess.Popen(
            [sys.executable, "-B", str(sequence_script), "--resume"],
            cwd=ROOT.parent,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    subprocess.Popen(
        ["/usr/bin/caffeinate", "-i", "-w", str(process.pid)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    attempt.update(outcome="resumed", pid=process.pid)
    save(history_path, history)
    return {"action": "resumed", "pid": process.pid, "reason": reason}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--sequence-script", type=Path, required=True)
    args = parser.parse_args()
    os.umask(0o077)
    state = args.state.resolve()
    with (state / ".supervisor.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with (state / ".runner.lock").open("a") as runner:
                fcntl.flock(runner, fcntl.LOCK_EX | fcntl.LOCK_NB)
                result = supervise(
                    state,
                    args.sequence_script.resolve(),
                    lambda: fcntl.flock(runner, fcntl.LOCK_UN),
                )
        except BlockingIOError:
            result = {"action": "running"}
        except (CampaignStop, Exception) as exc:
            result = {"action": "needs_review", "reason": str(exc)[:300]}
    save(state / "supervisor/latest.json", {"at": time.time(), **result})
    print(json.dumps(result))


if __name__ == "__main__":
    main()
