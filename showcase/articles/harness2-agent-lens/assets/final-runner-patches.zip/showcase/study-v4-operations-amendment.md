# Study v4: more concurrent workers

On October 23, 2026, the study owner authorized faster execution of the remaining
scheduled work, including further increases after checking the initial increase.
At the handover, 66 of 72 adaptation outcomes had been saved and none of the 252
held-out executions had started.

The runner now schedules the raw-feedback and diagnostics adaptations independently
after their shared baseline executions are complete. Each adaptation still follows
the same two sequential refinement rounds. Libraries and workspaces remain isolated.
The adaptation worker ceiling rises from two to eight, with a live limit that permits
a staged increase through four, six, and eight workers. The upstream proposer
semaphore must also permit eight sessions; its previous limit of two otherwise
leaves worker slots idle. The proposer override applies only while this amended
v4 adaptation dispatcher runs.

The owner subsequently authorized further increases when capacity allows. After
every adaptation is frozen, the held-out execution ceiling rises to 32. A separate
observed ramp proceeds through eight, 12, 16, 24, and 32 workers. This extension
takes effect in the next phase, without interrupting the active adaptations.
Four independent native grading jobs may run together after all executions finish;
each native JobBench grader retains its existing two-call rubric limit.

The recorded amendment is `runtime-repairs/parallel-throughput.json` in the campaign
state. It contains the qualified and amended source hashes, unchanged image and
analysis hashes, the scheduling policy, and a hashed validation log. The live
limit is `worker-control.json`; each new execution records its launch limit and
scheduling policy. The manifest, qualification receipt, prior frozen harnesses,
model settings, tasks, inference limits, scoring, and $500 ceiling are preserved.

The local Docker environment has 18 CPUs and approximately 29 GiB of memory.
Before increasing concurrency, active experiment workers used approximately
400 MiB each and the gateway used approximately 135 MiB. The preceding half hour
contained 257 completed provider requests with no recorded errors. Subsequent
checks compare actual worker activity, provider errors and request throughput,
memory use, accounting, and stored-trace verification before another increase.
Four, six, and eight active workers subsequently passed observed health windows
with no provider errors. At eight workers, total container memory use was about
21% of Docker's capacity. Each larger step requires at least two minutes of real
work, 30 completed requests, acceptable output throughput, and CPU and memory
headroom. The next step is also checked against projected memory use. New launches
are reduced if provider errors or memory pressure appear. These observations
support a capacity decision, not a measured end-to-end speedup.

At each dispatcher handover, active child executions are allowed to finish.
Their process receipts, raw events, workspaces, requests, and accounting survive
the handover. Durable recovery collects their results without repeating inference.
A queued operation can resume only if its original input hash matches and no
provider session was registered for it. Saved executions and frozen harnesses
remain the source of truth.

Local health checks run every five minutes. A bounded supervisor may resume a
missing controller, or retry a known transient trace-export failure, only when
child completion and settled accounting are proven. Trace recovery reuses the
saved execution. Semantic trace mismatches, model changes, uncertain child state,
unbounded usage, and budget halts still require review. Recovery is limited to
three attempts per hour and never publishes results automatically.

Quality analysis remains unchanged. Timing analysis must retain this scheduling
amendment: queue time and execution time are separate, and the earlier two-worker
adaptations should not be used as a controlled speed comparison with later work.

Validation covers upstream workflow behavior, eight concurrent upstream proposer
calls, shared worker limits through 32 containers, shared baseline evidence,
isolated conditions, saved and queued execution
recovery, grading barriers, unavailable judgments, concurrent budget reservations,
transport retry limits, trace readback, and conservative supervisor recovery.
