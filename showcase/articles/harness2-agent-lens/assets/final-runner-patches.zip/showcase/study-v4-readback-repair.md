# Study v4 empty-object trace readback repair

On October 22, 2026, adaptation stopped while verifying an adoption session. A shell command returned `{}\n`. Agent Lens retained the empty object in the raw stored span and the original text in tool metadata, but the normalized `tool_call_result` field was an empty string. The verifier treated that representation difference as evidence loss.

The v4 verifier now accepts this exact normalization only when the original result parses as an empty JSON object and the raw stored span independently contains that same object. Missing raw evidence, changed content, arrays, null, booleans and other results still fail. Earlier pilot behavior is unchanged.

The existing 29 spans for the affected session were read back and verified. No model request or tool execution was replayed. The campaign resumed through its durable operation records, retaining 98 frozen records, its original qualification, models, images, analysis, task selection and $500 ceiling.

A separate hashed repair receipt gates this source change. It permits only the earlier transport repair plus the telemetry verification and phase-gate files. Manifest, fixture, image and analysis changes still stop the runner. The 28 focused telemetry, recovery and upstream workflow tests passed, with two passing subtests; lint also passed.

At the pre-resume checkpoint, 65 of 72 adaptation outcomes were saved, and no final evaluations had executed. Measured inference cost was $123.679026, bounded unknown cost was $2.094581, and no requests were in flight. These are interim checkpoint values.
