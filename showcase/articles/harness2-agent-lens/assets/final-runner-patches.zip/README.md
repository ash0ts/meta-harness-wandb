# Final runtime changes

Base commit: 31b0f82b02e433545dc95b42fb2393996636ff6f
Repository: https://github.com/ash0ts/harness2-wandb

This preserves the operational repairs and worker scheduling changes already present when the study finished. It adds no new experiment or treatment. The original manifest and protocol remain in the base repository.

Check out that commit, run `git apply runner.patch`, then copy the included harness2/, tests/ and showcase/ files into the checkout. Read the two amendment notes before running. This is the final runtime state; individual execution records retain their actual settings and image identities.
